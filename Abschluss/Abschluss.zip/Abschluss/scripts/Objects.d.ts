declare namespace abschluss {
    class Objects {
        typ: string;
        xPos: number;
        yPos: number;
        width: number;
        height: number;
        size: number;
        constructor();
        update(): void;
        draw(): void;
    }
}
