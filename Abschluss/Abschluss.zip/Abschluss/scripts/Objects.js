/*
Abschlussaufgabe
Name: Annsophie Rösch
Matrikel: 257727
Datum: 28.07.2019

Hiermit versichere ich, dass ich diesen
Code selbst geschrieben habe. Er wurdeF
nicht kopiert und auch nicht diktiert.
*/
var abschluss;
(function (abschluss) {
    class Objects {
        constructor() {
        }
        update() {
        }
        draw() {
        }
    }
    abschluss.Objects = Objects;
})(abschluss || (abschluss = {}));
//# sourceMappingURL=Objects.js.map