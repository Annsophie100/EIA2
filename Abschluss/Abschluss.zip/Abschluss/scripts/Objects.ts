/* 
Abschlussaufgabe
Name: Annsophie Rösch
Matrikel: 257727
Datum: 28.07.2019

Hiermit versichere ich, dass ich diesen
Code selbst geschrieben habe. Er wurdeF
nicht kopiert und auch nicht diktiert. 
*/

namespace abschluss {

    export class Objects {

        typ: string;
        xPos: number;
        yPos: number;
        width: number;
        height: number;
        //counter
        size: number;

        constructor() {
        }

        update(): void {

        }

        draw(): void {
        }

    }

}