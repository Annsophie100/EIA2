declare namespace abschluss {
    let crc: CanvasRenderingContext2D;
    let canvas: HTMLCanvasElement;
    let score: number;
    let death: boolean;
    let eingabe: string;
    let allO: Objects[];
    let enemys: EnemyFishes[];
    let sharks: Shark[];
    let foods: Food[];
}
