interface Score {
    [key: string]: string;
}
interface Spieler {
    name: string;
    punkte: number;
}
