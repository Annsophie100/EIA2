declare namespace abschluss {
    function insert(): void;
    function refresh(): void;
}
